DEBUG = True

class Word:
    #set the constant list of all orientations
    ORIENTATIONS = ["HR", "HL", "VD", "VU", "DRD", "DRU", "DLD", "DLU"]
    
    #create the constructor which contains the word's spelling, orientation (defaulted to None), and location (also defaulted to none)
    def __init__(self, w, o = None, l =None):
        self.word = w
        self.orientation = o
        self.location = l
    #getters for all of the vairablse 
    @property
    def word(self):
        return self._word
    @property
    def orientation(self):
        return self._orientation
    @property
    def location(self):
        return self._location
    @word.setter
    def word(self, w):
        self._word = w
    @orientation.setter
    def orientation(self, o):
        self._orientation = o
    @location.setter
    def location(self,l):
        self._location = l
    def __str__(self):
        if DEBUG == False:
            return(self.word.upper())
        elif DEBUG == True:
            return(str(self.word) + "/" + str(self.orientation) + "@" + str(self.location))