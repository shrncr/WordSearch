#csc102
#Prof. Abi
#Sara Hrnciar
#location class
class Location:
    def __init__(self, r = 0, c = 0):
        self.row = r
        self.col = c
    @property
    def row(self):
        return self._row
    @property
    def col(self):
        return self._col
    @row.setter
    def row(self, r):
        if r > 0:
            self._row = r
        else:
            self._row = 0
    @col.setter
    def col(self, c):
        if c > 0:
            self._col = c
        else:
            self._col = 0
    def __str__(self):
        return ("(" + str(self.row) + "," + str(self.col) + ")")

# locs = []
# locs.append(Location(0,0))
# locs.append(Location())
# locs.append(Location(-3,-4))
# locs.append(Location(-3,7))
# locs.append(Location(7,-5))
# locs.append(Location(10,10))
# 
# for i in locs:
#     print(i)